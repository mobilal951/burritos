# Build a burrito dashboard using atoti

**Credit**: This notebook is contributed by [Ken Jee](https://www.youtube.com/c/KenJee1), who has been working in the data science field doing sports analytics for the last 5 years. He has held data science positions in companies ranging from startups to fortune 100 organizations.

On his YouTube channel, he produces fun and informative Data Science and Sports Analytics Content. His goal is to provide insight into the data science community, career advice, and sports related analysis.

Find the related YouTube video here 👉 https://www.youtube.com/watch?v=ammCGdzSoag&ab_channel=KenJee


